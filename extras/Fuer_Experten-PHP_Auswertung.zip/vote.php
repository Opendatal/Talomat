<?php

// Dies ist ein sehr simples Beispiel zur Auswertung der abgegebenen Stimmen.
// Die Routine zum Schreiben der Datei stammt von http://de3.php.net/manual/de/function.fwrite.php
// Wie in der definition.js erwaehnt, erhaelt das Skript zwei Variablen:
// mowpersonal und mowparties
// Diese werden hier zusammen mit dem Unix-Zeitstempel abgespeichert.
// Sie koennen natuerlich Daten auch in einer Datenbank (MySQL, ...) ablegen.

$filename = 'test.txt';
$somecontent = "\n".time()." ".$_GET["mowpersonal"]." ".$_GET["mowparties"];

// Sichergehen, dass die Datei existiert und beschreibbar ist
if (is_writable($filename)) {

    // Wir öffnen $filename im "Anhänge" - Modus.
    // Der Dateizeiger befindet sich am Ende der Datei, und
    // dort wird $somecontent später mit fwrite() geschrieben.
    if (!$handle = fopen($filename, "a")) {
         print "Kann die Datei $filename nicht öffnen";
         exit;
    }

    // Schreibe $somecontent in die geöffnete Datei.
    if (!fwrite($handle, $somecontent)) {
        print "Kann in die Datei $filename nicht schreiben";
        exit;
    }

    print "Fertig, in Datei $filename wurde $somecontent geschrieben";

    fclose($handle);

} else {
    print "Die Datei $filename ist nicht schreibbar";
}
?> 